#include "EventLoop.h"
#include "InetAddress.h"
#include "Logger.h"
#include "TcpServer.h"
#include <string>
#include <utility>

using namespace mymuduo;

class EchoServer
{
public:
    EchoServer(EventLoop* loop, const InetAddress& addr, std::string name)
        : loop_(loop), server_(loop, addr, std::move(name))
    {
        // 注册回调函数
        server_.setConnectionCallback([this](const TcpConnectionPtr& conn) { onConnection(conn); });
        server_.setMessageCallback(
            [this](const TcpConnectionPtr& conn, Buffer* buf, Timestamp ts) { onMessage(conn, buf, ts); });

        // 设置合适的 loop线程数量
        server_.setThreadNum(2);
    }

    void start() { server_.start(); }

private:
    void onConnection(const TcpConnectionPtr& conn)
    {
        if (conn->connected()) {
            LOG_INFO("echo connection up conn=%s peer=%s", conn->name().c_str(), conn->peerAddress().toIpPort().c_str());
        }
        else {
            LOG_INFO("echo connection down conn=%s peer=%s", conn->name().c_str(), conn->peerAddress().toIpPort().c_str());
        }
    }
    void onMessage(const TcpConnectionPtr& conn, Buffer* buf, Timestamp ts)
    {
        auto msg = buf->retrieveAllAsString();
        conn->send(msg);
        conn->shutdown();
    }

    EventLoop* loop_;
    TcpServer server_;
};

int main(int argc, char* argv[])
{
    InetAddress addr(8000);
    EventLoop loop;
    EchoServer server(&loop, addr, "EchoServer");
    server.start();
    loop.loop();   // 监听事件

    return 0;
}