#include "Logger.h"
#include "CurrentThread.h"

#include <chrono>
#include <cstdio>
#include <ctime>

using namespace mymuduo;

Logger& Logger::getInstance()
{
    static Logger logger;
    return logger;
}

const char* Logger::levelName(LogLevel level)
{
    switch (level) {
    case LogLevel::DEBUG: return "DEBUG";
    case LogLevel::INFO: return "INFO ";
    case LogLevel::ERROR: return "ERROR";
    case LogLevel::FATAL: return "FATAL";
    }
    return "UNKNOWN";
}

const char* Logger::basename(const char* path)
{
    if (path == nullptr) {
        return "unknown";
    }

    const char* base = path;
    for (const char* p = path; *p != '\0'; ++p) {
        if (*p == '/' || *p == '\\') {
            base = p + 1;
        }
    }
    return base;
}

std::string_view Logger::trimTrailingNewline(std::string_view msg)
{
    while (!msg.empty() && (msg.back() == '\n' || msg.back() == '\r')) {
        msg.remove_suffix(1);
    }
    return msg;
}

void Logger::log(LogLevel level, const char* file, int line, const char* func, std::string_view msg) const
{
    using namespace std::chrono;

    const auto now = system_clock::now();
    const auto sinceEpoch = now.time_since_epoch();
    const auto seconds = time_point_cast<std::chrono::seconds>(now);
    const auto microsecondsPart = duration_cast<microseconds>(sinceEpoch - seconds.time_since_epoch()).count();
    const auto time = system_clock::to_time_t(now);

    tm localTime{};
    localtime_r(&time, &localTime);

    char timeBuf[128]{};
    std::snprintf(timeBuf,
                  sizeof(timeBuf),
                  "%04d-%02d-%02d %02d:%02d:%02d.%06ld",
                  localTime.tm_year + 1900,
                  localTime.tm_mon + 1,
                  localTime.tm_mday,
                  localTime.tm_hour,
                  localTime.tm_min,
                  localTime.tm_sec,
                  static_cast<long>(microsecondsPart));

    msg = trimTrailingNewline(msg);
    const char* safeFunc = func == nullptr ? "unknown" : func;
    std::FILE* out = (level == LogLevel::ERROR || level == LogLevel::FATAL) ? stderr : stdout;

    std::lock_guard<std::mutex> lock(mutex_);
    std::fprintf(out,
                 "[%s] %s [tid=%d] %-18s:%-4d %-24s - %.*s\n",
                 levelName(level),
                 timeBuf,
                 CurrentThread::tid(),
                 basename(file),
                 line,
                 safeFunc,
                 static_cast<int>(msg.size()),
                 msg.data());
    std::fflush(out);
}
